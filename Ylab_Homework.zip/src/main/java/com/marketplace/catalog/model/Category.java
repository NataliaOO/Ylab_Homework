package com.marketplace.catalog.model;

/**
 * Категории товаров в каталоге.
 */
public enum Category {
    ELECTRONICS,
    CLOTHES,
    BOOKS,
    HOME,
    BEAUTY
}
